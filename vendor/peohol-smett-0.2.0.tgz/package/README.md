# Smett

**Smett is an opinionated drag-and-drop policy layer built on the framework-agnostic dnd-kit core. It preserves interaction invariants distilled from Huskis while delegating generic drag-and-drop infrastructure to dnd-kit.**

Smett is not an engine. Pointer and keyboard sensors, activation constraints, the
collision framework, sorting, drag feedback, drop animation, auto-scroll, live
regions, nested gesture ownership and the plugin/modifier system all belong to
[dnd-kit](https://github.com/clauderic/dnd-kit) and are used as they ship. What
Smett adds is a short list of behaviours that dnd-kit deliberately leaves open,
each of which exists because a real application was worse without it.

## What Smett owns

| Policy | Why it is not upstream's |
| --- | --- |
| **Reorder hysteresis** | dnd-kit's `directionBiased` detector has no memory, so a pointer that twitches backwards flips the order back the frame after it changed. Smett's detector keeps Huskis' asymmetry: a forward swap needs 20% overlap and is eager, undoing that swap is refused for 300 ms and then costs 50%. |
| **Release-authoritative placement** | dnd-kit coalesces pointer moves onto an animation frame and then ends the operation straight from `pointerup` without feeding those coordinates in. A flick that outruns the last frame drops where the previous frame thought it was. Smett applies the real release position before the operation ends, and reconciles the DOM to it synchronously — and runs the same decision early into an empty container, the one place dnd-kit's own sorting has no row to move the placeholder with. |
| **Innermost target wins** | An item that holds a container of its own encloses every row in it, so both collide with the drag and whose centre is nearer decides — which flips as the pointer moves, and the reverse lock flips it back. Smett settles it by region: a host declines while the pointer is inside the container it holds, so a drop aimed into a category lands there every frame, and a category dragged among categories still swaps with its peers. |
| **Intent versus paint** | The reorder decision reads the *unclamped* pointer rectangle, never the clamped feedback element. A user can intend a position the paint is not allowed to reach. |
| **Safe-area clamping** | `RestrictToWindow` clamps to the viewport. `SafeViewport` clamps to the viewport minus insets an application can move at runtime, and centres content larger than the space left over instead of pinning it to one edge. |
| **Transactional commit** | dnd-kit has no notion of persistence, so it has no notion of persistence failing. A Smett drop is optimistic in the DOM and transactional in the data: a rejected `onCommit` restores the order the drag started from. |
| **Strict semantic identity** | dnd-kit takes the id it is handed. Smett derives ids from the DOM, so it owns the question of whether an identity is trustworthy enough to persist a reorder against: missing or duplicate ids fail fast, and the clone dnd-kit leaves behind never claims an item's identity. |
| **Semantic drop zones** | A zone is an application action target, not another sortable container. The engine reports which zone received which item and restores the item first; deleting, archiving and assigning stay in the application. |

Everything else is upstream's, on purpose. If you are about to write a sensor, a
collision algorithm, a scroll loop or a coordinate system inside Smett, that is
the signal that it belongs in dnd-kit instead.

## Packages

Smett depends on four dnd-kit packages, all pinned to the `0.5.x` line while
that series is pre-1.0:

| Package | Used for |
| --- | --- |
| `@dnd-kit/dom` | `DragDropManager`, `PointerSensor`, `KeyboardSensor`, `Feedback`, `AutoScroller`, `Accessibility`, `Sortable`, `RestrictToWindow` |
| `@dnd-kit/abstract` | `Plugin`, `Modifier`, `Sensor`, the axis modifiers, collision types, entity registry |
| `@dnd-kit/collision` | `pointerIntersection` for containers and zones |
| `@dnd-kit/geometry` | `Rectangle`, `Point` for the policy maths |

## Install and build

```bash
npm install
npm run build
npm test
npx playwright install chromium firefox webkit
npm run test:e2e:all
```

`npm run build` produces four artefacts, none of them committed:

| Artefact | For |
| --- | --- |
| `dist/` | Unbundled ESM plus type declarations — npm consumers with a bundler or Node resolution |
| `dist/smett.browser.js` | One self-contained module for `<script type="module">`, because bare specifiers such as `@dnd-kit/dom` do not resolve in a browser |
| `dist/smett.browser.min.js` | The same module, minified — for an application that vendors the file and ships it over the network |
| `dist/smett.iife.js` | Minified, for a classic `<script>`; defines the global `Smett` |

The last two are the same library said twice, because the two consumers who have
no bundler do not have the same problem.

An application that loads modules can vendor `smett.browser.min.js` and import it
by path, and the readable build is then a debugging aid rather than the thing it
ships — a phone on a slow connection is not the place to pay for the whitespace:

```html
<script type="module" src="js/app.js"></script>   <!-- imports ./vendor/smett.js -->
```

The IIFE exists for applications that have deliberately not got a bundler and do
not want one *and* still have classic scripts. Loading a module script is not an
equivalent for them: a module always executes after every classic script on the
page, so a library loaded that way cannot be there for a classic script that runs
before it.

```html
<script src="vendor/smett-0.2.0.js"></script>
<script src="app.js"></script>          <!-- window.Smett is already there -->
```

Everything the ESM entry point exports is on that global, dnd-kit's own
re-exports included.

A consumer that vendors that file checks a copy in against a claim — a hash, or
"this is what the build produces at commit X" — and the claim is only worth
making if the build is reproducible. It is: `esbuild` is pinned to an exact
version rather than a range, because a minifier is free to change its output
between patch releases and a range would silently make the same source produce a
different file. `npm ci && npm run build` at a given commit therefore gives the
same bytes on any machine, for either minified artefact, which is what a
vendoring consumer's guard tests against.

## Minimal use

```ts
import { SortableBoard } from '@peohol/smett';

const board = new SortableBoard({
  root: document.querySelector('#board')!,
  itemSelector: '.card',
  containerSelector: '.column',
  handleSelector: '.drag-handle',
  zoneSelector: '.trash',

  async onCommit(result) {
    // Persist result.itemId, result.to.containerId and result.to.index.
    // Throw to roll the board back.
  },

  onZoneDrop(result) {
    if (result.zoneId === 'trash') archive(result.itemId);
  },
});
```

Expected markup:

```html
<div id="board">
  <section class="column" data-dnd-container="todo">
    <article class="card" data-dnd-id="a">
      <button class="drag-handle" aria-label="Move A">⠿</button>
      A
    </article>
  </section>

  <aside class="trash" data-dnd-zone="trash">Delete</aside>
</div>
```

Stable identities are mandatory. Every item, container and configured zone needs
a unique value in its data attribute (or a DOM `id`). Construction fails fast on
a missing or duplicated one; the engine never invents a persistence identity.

For reliable touch dragging on a dedicated handle, apply `touch-action: none` to
that handle. An activated drag owns its gesture, so wherever a drag *can* start
is a region the finger can no longer scroll from. `handleRequiredFor` scopes the
handle requirement per input kind, which is usually what you want when draggable
items fill a scrollable surface:

```ts
handleSelector: '.drag-handle',
handleRequiredFor: ['touch', 'pen'],   // a mouse still lifts from anywhere on the item
```

## Reaching dnd-kit

The board exposes the manager it built, and the package re-exports the dnd-kit
primitives, so nothing is hidden behind a Smett-shaped copy of it:

```ts
board.manager.monitor.addEventListener('dragmove', (event) => { … });
board.manager.registry.plugins.register(MyPlugin);

const { plugin, options } = RestrictToVerticalAxis;
board.manager.registry.modifiers.register(plugin, options);
```

The geometric constraints are upstream's, re-exported rather than reimplemented.
A list that only reorders vertically wants `RestrictToVerticalAxis`, and it is
paint alone: the reorder still reads the unclamped pointer, so locking the axis
changes where the card is drawn and not where it lands.

Register a modifier rather than re-assigning `manager.modifiers`: that list
reads as instances and writes as constructors, so a round trip through it hands
the registry something it cannot construct. See
[`docs/extensions.md`](docs/extensions.md#reaching-dnd-kit).

`createSmettManager()` gives you the same manager without the DOM board, for an
application that registers its own `Sortable` entities — a React or Vue adapter,
say — but still wants Smett's policies:

```ts
import { createSmettManager } from '@peohol/smett';

const manager = createSmettManager({
  hysteresis: { reverseLockMs: 450 },
  safeInsets: () => ({ top: header.offsetHeight, right: 0, bottom: 0, left: 0 }),
});
```

Each policy is also exported on its own — `Hysteresis`, `hysteresisCollision`,
`AuthoritativeDrop`, `SafeViewport`, `activationConstraints` — so it can be added
to a plain `DragDropManager` you built yourself.

## CSS hooks

dnd-kit lifts the item itself into the top layer and leaves a hidden clone in the
layout to hold its place:

| Selector | Meaning |
| --- | --- |
| `[data-dnd-dragging]` | The lifted item, while it is being dragged |
| `[data-dnd-placeholder]` | The clone holding its slot (`visibility: hidden` by default) |
| `[data-dnd-over]` | The current drop target — `item`, `container` or `zone` |
| `.smett-announcer` | Smett's live region for announcements outside a drag |

To draw the familiar empty-slot outline, style the clone's own box and hide its
contents:

```css
.card[data-dnd-placeholder] { visibility: visible; border: 2px dashed; background: …; }
.card[data-dnd-placeholder] > * { visibility: hidden; }
```

One reduced-motion caveat is worth knowing. The lifted element is positioned
through custom properties, so the usual global reset —

```css
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after { transition-duration: 0.001ms !important; }
}
```

— transitions the engine's own `top` and `left` too. That is not "no motion", it
is "all motion, very fast", and WebKit resolves those properties from their
fallback for a frame, so the lifted element flashes at the viewport origin. Ask
for what you meant instead:

```css
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after { animation: none !important; transition: none !important; }
}
```

## Keyboard and non-drag operation

Keyboard dragging is dnd-kit's `KeyboardSensor` with Smett's announcements:

- `Space` / `Enter`: pick up or drop the focused item.
- Arrow keys: move within and between containers.
- `Escape`: cancel and restore the original location.

Semantic zones are pointer targets by design — a keyboard drag would otherwise
have an arrow press swallowed by an archive strip it cannot see. Applications
owe keyboard users an ordinary control for the same action; the Release Board
has one on every card.

For WCAG 2.2 dragging-movement alternatives, `board.moveBy(item, ±1)` reorders
within a container and `board.moveTo(item, containerId, index)` moves anywhere on
the board. Both commit through the same transaction as a drop, and both go
through the same acceptance gate: a container that refuses the drag refuses the
move. `board.accepts(item, containerId)` asks that question up front, so a
control for a move that cannot happen need never be offered.

### Saying it in another language

The announcements are English by default. `phrases` replaces the builders
themselves, which is what an application with its own dictionary needs — a board
says the same sentence in three places (dnd-kit's live region, `onAnnounce`, and
Smett's own announcer for a programmatic move or a rejected save), and only
replacing the builders covers all three:

```ts
new SortableBoard({
  …,
  phrases: {
    pickedUp: (label, position) => `Løftet ${label}. ${position}.`,
    inContainer: (index, total, container) =>
      `plass ${index + 1} av ${total} i ${container}`,
  },
});
```

Anything left out keeps Smett's English. `index` is zero-based and `total`
counts the item itself, because a translation needs both numbers rather than a
formatted English fragment.

## Demo and showcase app

| Path | Purpose |
| --- | --- |
| `demo/` | A deliberately minimal fixture. The library's browser tests drive it, so it stays boring on purpose. |
| `app/` | **Release Board** — a small real application on the published API, deployed to Vercel and covered by its own UI suite. |

```bash
npm run dev:app                # builds public/ and serves the app on http://127.0.0.1:4321
python3 -m http.server 4173    # the raw fixture, at http://localhost:4173/demo/
```

See [`docs/app.md`](docs/app.md) for what each Release Board control
demonstrates, how it is deployed, and how to run the UI suite against a
deployment.

## Design documents

- [`docs/architecture.md`](docs/architecture.md) — who owns what, and the invariants that justify Smett existing at all.
- [`docs/huskis-extraction.md`](docs/huskis-extraction.md) — what came from Huskis, what dnd-kit now provides instead, and what was dropped.
- [`docs/agent-guide.md`](docs/agent-guide.md) — implementation protocol for AI coding agents.
- [`docs/extensions.md`](docs/extensions.md) — zones, peek affordances, nesting, framework adapters and persistence.
- [`docs/app.md`](docs/app.md) — the Release Board showcase app.
- [`docs/roadmap.md`](docs/roadmap.md) — what is settled, what is deferred, and what to watch upstream.
- [`AGENTS.md`](AGENTS.md) — short repository-wide rules for coding agents.

## Validation

CI runs on Node 22: strict TypeScript, 17 deterministic unit/fuzz tests over the
pure policies, 43 library browser scenarios and 28 Release Board UI scenarios in
each of Chromium, Firefox and WebKit. The browser suites cover mouse, touch and
keyboard activation, the handle policy, forward reorder and reversal hysteresis,
cross-container drags, semantic zones, release-authoritative placement,
`pointercancel`, detached nodes, failed commits, strict identity, boards sharing
one manager, nested boards, window and ancestor auto-scroll, safe-area clamping,
live-region announcements and reduced motion.

## Stability

This is `0.1.x`, and it now tracks a pre-1.0 upstream. dnd-kit `0.5.x` is pinned
deliberately; treat a minor bump there as a change that needs the browser suites
run before it is believed. Smett's own API may still change while it is
integrated into more applications.
