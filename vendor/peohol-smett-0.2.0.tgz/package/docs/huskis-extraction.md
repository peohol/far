# Huskis mechanics, and where they live now

Source audited: `peohol/huskis` at commit `c7dc39f70aa2e6a9077ca9364f1105bf78359209`.

Huskis is a large vanilla-JS application with a custom Pointer Events engine. The
first version of this repository extracted that engine and generalised it. This
version keeps the *behaviour* and gives the engine away: dnd-kit already
implements most of it, better tested and in more browsers than one application's
extraction ever will be.

The table below is the audit that decided each case.

## Delegated to dnd-kit

The behaviour is preserved. The code is gone.

| Huskis behaviour | dnd-kit equivalent |
| --- | --- |
| Pointer Events across mouse, touch and pen | `PointerSensor` |
| Ignore secondary pointers | `event.isPrimary` guard in `PointerSensor` |
| One drag at a time | `DragOperation` status machine |
| Movement/hold activation thresholds | `PointerActivationConstraints.Distance` / `.Delay` |
| The gesture starts from the current pointer position | dnd-kit tracks from `pointerdown` and transforms by the delta, which keeps the grab point under the finger exactly — the same guarantee, expressed better |
| Native pan blocked while a drag is live | `PointerSensor` binds a non-passive `touchmove` guard at activation |
| Directional overlap-based reordering | the collision framework, `directionBiased`, and `Sortable` |
| DOM reordering during the drag | `OptimisticSortingPlugin` |
| Placeholder holding the lifted item's slot | `Feedback`'s placeholder clone |
| Document-level drag proxy | `Feedback` lifts the element into the top layer via `popover` |
| Lifted item animating into its slot on drop | `Feedback`'s drop animation |
| FLIP movement of neighbours | `Sortable`'s index transition |
| Measuring around an in-flight animation | `PositionObserver`-driven droppable shapes |
| Reduced-motion support | `prefersReducedMotion` in `Feedback` and `Sortable` |
| Elapsed-time auto-scroll, `dt` clamping | `AutoScroller` and `Scroller` |
| Scrollable-ancestor discovery and handoff | `getScrollableAncestors`, `ScrollIntentTracker` |
| Placement re-evaluated after scrolling | `ScrollListener` plus shape observers |
| `pointercancel` rolls back | `PointerSensor.handleCancel` |
| Escape cancels | `PointerSensor` and `KeyboardSensor` |
| Focus loss alone does not cancel | dnd-kit listens for none of `blur`, `visibilitychange`, `lostpointercapture` |
| Nested levels cannot both claim one gesture | `event.sensor` stamping in `PointerSensor` |
| Live-region announcements | `Accessibility` |
| Keyboard pick up, move, drop, cancel | `KeyboardSensor` and `SortableKeyboardPlugin` |
| Viewport clamping | `RestrictToWindow` — extended, not replaced, by `SafeViewport` |

## Kept, because dnd-kit does not offer the same guarantee

| Huskis behaviour | Where it lives now | Why |
| --- | --- | --- |
| 20% forward swap, 300 ms reverse lock, 50% reverse overlap | `hysteresis.ts` | `directionBiased` has no memory of the swap it just made, so a one-pixel twitch flips the order back |
| Same-lane requirement for a neighbour | `hysteresis.ts` (`crossAxisRatio`) | A card in the next column shares this one's whole vertical band; measuring only the axis of travel makes it a swap candidate |
| `pointerup` performs a final authoritative placement | `authoritative-drop.ts` + the board's `dragend` reconcile | dnd-kit coalesces moves onto a frame and ends the operation without applying the release coordinates |
| Intent rect unclamped, feedback clamped | `hysteresis.ts` reconstructs the intent rectangle | `dragOperation.shape` follows the painted element, which modifiers may have clamped |
| Safe-area aware clamp, oversized content centred | `safe-viewport.ts` | `RestrictToWindow` has neither insets nor an answer for content larger than the viewport |
| Huskis' exact activation numbers | `activation.ts` | dnd-kit's defaults are close but different, and these are the tuned ones |
| A handle requirement scoped per input kind | the board's `preventActivation` | Not a dnd-kit concept; it is a trade an application should choose |
| Semantic drop zones as actions | the board's zone droppables | dnd-kit has droppables, not "an action target that restores the item first" |
| Stable unique identities, enforced | `identity.ts` | dnd-kit takes the id it is handed; Smett derives ids from the DOM and therefore owns their trustworthiness |
| A detached dragged node is let go of, never reinserted | the board's `MutationObserver` | dnd-kit goes on dragging a node an external render removed |
| Async commit with rollback | the board's transaction | dnd-kit has no notion of persistence, so none of persistence failing |
| Position-aware announcements | `announcements.ts` | dnd-kit's default phrasing describes a generic drag |
| A non-drag path for every drag action | `moveBy` / `moveTo` | An accessibility requirement, not a gesture |

## Dropped

- **`HoverIntent`.** A dwell-then-open primitive. It was never a drag-and-drop
  invariant, and with `onDropTarget` reporting what the drag is over, an
  application implements it in five lines. Kept in Smett it would only have been
  a utility looking for a home.
- **The geometry module.** Matrix composition, ancestor transform inversion,
  rect intersection and `settledRect`. All of it existed to keep a hand-written
  FLIP implementation honest under transformed ancestors. dnd-kit's shapes and
  transitions make the whole problem someone else's.
- **The scroll and auto-scroll modules.** `FrameStepper`, `edgeVelocity`,
  scrollable-target selection and the RAF loop.
- **The ownership module.** A module-level map of pointer ids to owners,
  replaced by dnd-kit stamping the event.
- **The motion module.** FLIP, landing tweens, and reading a painted position
  back out of `translate`.
- **The `SortableController`.** 654 lines of pointer handling, placement,
  scrolling, animation and DOM transaction in one class.

## Generalised rather than copied

### Board columns

Huskis has explicit `.board-col` containers and freezes column distribution
during a drag, because its responsive board model requires it. Smett requires
real container elements via `containerSelector` and never treats a CSS
multi-column flow as an authoritative item container.

### Extracting an item into a new list

Huskis reads "dragged into board air" as intent to create a new list. In another
application the same gesture means unassign, move to root, create group, or
nothing at all. Model it as a semantic zone; see [`extensions.md`](extensions.md).

### Collapsed list peek

Huskis opens a collapsed target after about 200 ms and restores it if the pointer
leaves. Smett reports the drop target through `onDropTarget`; the delay and what
"open" means are the application's.

### Persistence

Huskis rebuilds state from the DOM at drop and stamps its own position registers.
Smett emits a typed result and lets the consumer decide whether the authoritative
state is the DOM, framework state, a CRDT or a database.

## Regression scenarios a consumer should preserve

The library suite in `e2e/` covers all of these; a consumer adapting Smett should
keep equivalents:

1. mouse activation only after real movement, and a click that stays a click;
2. touch long-press activation, and drift during the hold that keeps the swipe;
3. a handle requirement scoped per input kind;
4. a release whose coordinates the last delivered move never carried;
5. forward reorder, and a reversal that costs more than the move that caused it;
6. a card in the next column that is not a neighbour of this one;
7. cross-container transfer, and a drop into an empty container;
8. semantic zone drops, and zone actions that reject;
9. window auto-scroll and scrollable-ancestor auto-scroll;
10. safe-area clamping with no page overflow;
11. `pointercancel`, `Escape`, and the events that must *not* cancel;
12. a dragged node removed by an external render;
13. a rejected commit rolling back to the original index in the original container;
14. missing and duplicate identities;
15. nested boards arbitrating one gesture;
16. keyboard pick up, move, transfer, drop and cancel;
17. single-action alternatives to every drag action;
18. announcements for pick up, movement, drop, cancel and failure;
19. reduced motion.
