# Roadmap

## Settled by the dnd-kit migration

The first hardening pass built an engine. This one gave it away. What that
resolved, permanently:

- Sensors, activation machinery, collision framework, sorting, drag feedback,
  drop animation, auto-scroll, live regions and nested gesture ownership are
  upstream's, and are no longer maintained here.
- The four API gaps the Release Board recorded against the old controller are
  closed: announcements are routable (`onAnnounce`), the active drop target is
  published (`onDropTarget` and `[data-dnd-over]`), `moveTo()` crosses
  containers, and per-item drop rules are expressible through dnd-kit's own
  `accept` on the entities the board registers.
- `canDrop` as a bespoke hook is no longer missing: it is dnd-kit's `accept`,
  and an application that needs finer control can reach the entities through
  `board.manager.registry`. `itemType` and `containerAccept` route the common
  case — one board, two kinds of item, one of which must not nest — through that
  same gate without an application reaching into the registry at all.
- An application without a bundler is a supported consumer: `dist/smett.iife.js`
  is a classic script defining one global, which is the only shape that can load
  before another classic script on the same page.
- The announcements are no longer only English. `phrases` replaces the builders
  the board calls, which is what reaches all three routes a sentence takes.

## Deliberately deferred

### Framework adapters

A React or Vue adapter should be a thin package built once the core API has been
exercised by more than two applications. It is now a much smaller job than it
was: an adapter registers dnd-kit `Sortable` entities against a
`createSmettManager()` manager and never touches `SortableBoard`.

### Virtualised and very large collections

Neither consumer has one. `BoardRegistry` re-scans the DOM on mutation, which is
fine for a board and wrong for ten thousand rows. The seam is already there —
the registry is a separate module with a small interface — so the work is a
second registry, not a rewrite.

### Roving tabindex

The board gives every item `tabindex="0"`. A roving-tabindex policy may be
worthwhile for very large collections, but it should be optional, because
applications often own focus management already.

## Watch upstream

These are dnd-kit behaviours Smett currently lives with. Each should be
re-checked when the dependency is bumped, and each is a candidate for an upstream
issue rather than a local workaround.

- **Auto-scroll speed is per frame, not per elapsed millisecond.** `AutoScroller`
  drives `Scroller.scroll()` from a 10 ms interval scheduled onto animation
  frames, so a 120 Hz display scrolls faster than a 60 Hz one. It is bounded at
  both ends (the interval caps the rate, and animation frames do not run in a
  background tab), so there is no large-`dt` jump to guard against — but it is
  not the elapsed-time model Huskis had.
- **The release position is not applied on `pointerup`.** `PointerSensor`
  coalesces moves onto an animation frame and then calls `actions.stop()`
  directly. `AuthoritativeDrop` exists entirely to close this, and would be
  better as an upstream option.
- **The last collision result is applied asynchronously.**
  `OptimisticSortingPlugin` reorders through a microtask and a render tick, so a
  drop in the same tick commits the previous order. The board reconciles
  synchronously at `dragend` for this reason.
- **`setPointerCapture` failure is fatal to the drag.** `PointerSensor` cancels
  the operation if capture throws. That is defensible for a released pointer, but
  it also means synthetic `PointerEvent`s cannot drive a drag at all — which
  costs test harnesses that used to dispatch them.
- **The live region is created on the animation frame after the first draggable
  registers.** A drag started before that frame produces no announcement. It is
  unreachable for a human, but it is why Smett's own `onAnnounce` is emitted from
  the board rather than from inside the plugin's announcer.
- **The placeholder clone carries the original's attributes.** Smett strips its
  own identity attributes from it; an application's `data-testid` and similar are
  still duplicated for the duration of a drag.
- **The lifted element is positioned through custom properties.** A page that
  transitions *all* properties — which the common reduced-motion reset
  (`transition-duration: 0.001ms !important` on `*`) does — transitions `top` and
  `left` too, and WebKit resolves them from their fallback for a frame, painting
  the element at the viewport origin. Worse, dnd-kit re-measures the element into
  `dragOperation.shape` in that state, so an input arriving in the same frame
  resolves against the wrong rectangle. The demo and the app now ask for
  `transition: none` instead, and the README says why; upstream could stop
  copying the page's `transition` shorthand onto the feedback element.

## What could still be delegated

The question this project should keep asking itself. As of the migration, the
honest answer is "about 150 of roughly 1,100 lines", and each of them is waiting
on something upstream:

| Smett code | Could go away if | Tracked above as |
| --- | --- | --- |
| `authoritative-drop.ts` | `PointerSensor` applied the release coordinates before stopping | "The release position is not applied on `pointerup`" |
| The board's `settle()` and `order.ts`'s `insertByPoint` | `OptimisticSortingPlugin` applied the last collision result synchronously at `dragend` | "The last collision result is applied asynchronously" |
| `safe-viewport.ts` | `RestrictToWindow` took insets and centred oversized content | — (worth an upstream proposal) |
| The board's `trackDropTarget` | dnd-kit marked the current drop target in the DOM | — (worth an upstream proposal) |
| `identity.ts`'s `stripIdentity` | `Feedback` offered a hook over the placeholder clone it creates | "The placeholder clone carries the original's attributes" |

What cannot be delegated, and is the reason Smett exists: `hysteresis.ts` (the
reorder policy), the commit transaction, strict identity, the position-aware
announcements, and `registry.ts` (there is no DOM-scanning binding upstream — the
React adapter does this job inside React).

`activation.ts` is a special case: it *could* be deleted by accepting dnd-kit's
default constraints. It is kept because Huskis' numbers are the tuned ones, and
that is the whole justification. If they ever stop earning their keep, delete it.

## Next validation tier

- Integrate into a third consumer with a different shape — virtualised, or very
  large — before stabilising the public API.
- Keep Chromium, Firefox and WebKit regression CI mandatory before `1.0`.
- Re-run the browser suites on every dnd-kit minor bump while it is pre-1.0, and
  record anything that moves in the list above.
