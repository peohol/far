# Extension patterns

Smett is a thin layer, so most extension happens either in the application or
directly against dnd-kit. This document is about which of the two.

## Reaching dnd-kit

`board.manager` is an ordinary `DragDropManager`. Anything dnd-kit can do to one,
you can do to this one:

```ts
board.manager.monitor.addEventListener('dragmove', ({ operation }) => { … });
board.manager.registry.plugins.register(MyPlugin);

// A modifier the board did not build: register it, do not re-assign the list.
const { plugin, options } = RestrictToVerticalAxis;
board.manager.registry.modifiers.register(plugin, options);
```

Register rather than assign, and it is upstream's asymmetry that decides it:
`manager.modifiers` **reads** as the live plugin *instances* and **writes** as
constructors or `{plugin, options}` descriptors. `[...manager.modifiers, Mine]`
therefore hands an instance back where a constructor is expected, and the
registry throws on `new instance()`. Registering adds to what the board already
built, which is also what you want — `SafeViewport` stays.

If you do not want the DOM board at all — a React or Vue adapter that registers
its own `Sortable` entities, say — `createSmettManager()` gives you the same
manager with Smett's policies and nothing else:

```ts
import { createSmettManager } from '@peohol/smett';
import { Sortable } from '@dnd-kit/dom/sortable';

const manager = createSmettManager({ hysteresis: { reverseLockMs: 450 } });
new Sortable({ id, index, group, element, collisionDetector: hysteresisCollision() }, manager);
```

Each policy is exported on its own, so it can be added to a manager you built
yourself: `Hysteresis` and `hysteresisCollision()`, `AuthoritativeDrop`,
`SafeViewport`, `activationConstraints()`.

## Semantic drop zones

A zone is an application action target, not another sortable container.

```ts
new SortableBoard({
  root,
  itemSelector: '.task',
  containerSelector: '.lane',
  zoneSelector: '[data-dnd-zone]',
  onZoneDrop({ itemId, zoneId }) {
    if (zoneId === 'archive') return archive(itemId);
  },
});
```

The board restores the item to its origin before invoking the action, so a
rejected action leaves the board exactly as it was. Zones are pointer targets by
design — dnd-kit's keyboard navigation would otherwise have an arrow press
swallowed by a zone the user cannot aim at — so give keyboard users an ordinary
control for the same action.

## Reacting to what the drag is over

`onDropTarget` reports the current target and its kind, and the board mirrors it
onto the element as `[data-dnd-over="item|container|zone"]`. Between them they
replace any need to re-run hit-testing in the application.

A dwell-then-open "peek" affordance is four lines on top of it:

```ts
let timer;
onDropTarget(target) {
  clearTimeout(timer);
  if (target?.id !== 'archive') return zone.classList.remove('is-peeking');
  timer = setTimeout(() => zone.classList.add('is-peeking'), 400);
}
```

## "Drop outside to create" semantics

Do not put this in the reorder policy.

1. Render an application-specific target such as "Create group here".
2. Mark it as a semantic zone.
3. In `onZoneDrop`, create the container and move the entity in one application
   transaction.

## Nested hierarchies

Prefer a separate board per hierarchy level, each with its own selectors and
identity attributes:

- board controller: cards between columns;
- card controller: items within and between cards.

Each board builds its own manager, and dnd-kit stamps the `pointerdown` event
with the sensor that claimed it, so the innermost board wins a shared press. Use
`data-dnd-ignore` on anything inside an item that must keep its own activation.

To put several boards in one gesture space instead — so an item can be dragged
between them — pass the same `manager` to each.

Both boards then see every drag, and only the one the item belongs to describes
it: the other returns nothing, for its own `onAnnounce` and for the shared live
region alike. Their `phrases` reach that region too, even though neither board
built the manager — dnd-kit's accessibility plugin reads its announcements once
at construction, so the first board to attach rebuilds it with the same options
plus a callback that asks each board in turn. One live region, whichever board
owns the gesture.

## Item kinds, and containers that turn one away

Sometimes a level is not a separate board: two kinds of thing genuinely share a
container, and one of them owns a container of its own. A category that sits
among rows and holds rows is the case — and it must never end up inside another
category.

That is a rule about kinds, and dnd-kit already gates on kinds. Name them with
`itemType`, and say what each container takes with `containerAccept`:

```ts
new SortableBoard({
  itemSelector: '.row, .category',
  containerSelector: '.items',
  itemType: (item) => (item.matches('.category') ? 'category' : 'row'),
  containerAccept: (container) =>
    (container.closest('.category') ? ['row'] : ['row', 'category']),
});
```

Five things follow, and they are the reason this is not a policy module:

- The refusal happens **during** the drag, at dnd-kit's `accept` gate. A
  container that will not take the item never becomes a target, so there is no
  drop to undo afterwards.
- `moveTo()` is refused by the same gate, asked of the same droppable. The
  single-action alternative to a drag has to be an alternative to it, not a way
  round it. `accepts(item, containerId)` answers the question in advance, so the
  control can be left off the menu rather than doing nothing when pressed.
- An item accepts whatever its own container accepts. "May this land here?" is
  one question, and answering it differently for a slot and for the row in it
  would let a drag swap with a neighbour its container had already refused.
- A category **declines while the pointer is inside it**. It encloses every row
  it holds, so both it and the row under the pointer collide with the drag, and
  left to whose centre is nearer the answer flips as the pointer moves — neither
  is reliably closer — and the reverse lock then refuses the swap that just
  happened and flips it back. A region settles it, because the answer wanted is
  not "the nearer one" but "the inner one":

  - inside the container it holds, a category is not a candidate at all, so the
    row under the pointer decides;
  - anywhere else on it — its header, the gap beside it, an empty one — it is an
    ordinary neighbour, level with its peers, which is what dragging categories
    among categories needs.

  It stands down only for rows that could actually take the drag — the same
  `accept` gate above. A category holding rows has nothing to offer a dragged
  *category*, so standing down over its drawer would be standing down for
  nobody, and the whole of its box stays an ordinary neighbour.

  It has to be a region rather than a rank. dnd-kit compares one priority number
  globally, so "below my rows, level with my peers" cannot be said at all:
  demoting a category puts it below the list it sits in as well, and a list whose
  items are *all* categories then never reorders, because the container wins every
  frame and no sibling is ever the target.
- `containerAccept` is read on every sync, so a container whose answer depends
  on application state — a mode that suspends reordering, say — stays current
  without re-registering anything. An empty array is how such a mode says "not
  right now": the container takes no kind at all until it says otherwise.

Omit both and every item is the same kind and every container takes all of them,
which is what a board with one kind of thing wants.

Boards sharing a manager do not have to share a vocabulary: the kinds are
namespaced internally, so a zone still recognises an item from a board whose
kinds it has never heard of.

Nesting also means the lifted element is cloned **with its subtree**. Everything
inside the clone is the clone — Smett's DOM scans skip the whole of it, so the
rows copied along with a lifted category are neither a second element with the
same id nor an item that has lost its own.

## Framework adapters

Smett manipulates the DOM optimistically during a gesture and reports the
committed location afterwards. An adapter should:

1. mount the board after the root DOM exists;
2. provide stable item and container keys in data attributes;
3. update framework state only from `onCommit` / `onZoneDrop`;
4. avoid replacing the dragged DOM node during an active drag;
5. destroy the board on unmount.

For a framework that owns its own list rendering, consider skipping
`SortableBoard` entirely and registering dnd-kit `Sortable` entities against a
`createSmettManager()` manager — that is the thinner integration, and it keeps
every Smett policy.

## Persistence models

### Simple array state

Convert `{containerId, index}` into an array splice.

### Database positions

Do not re-stamp every item if the database supports fractional or rank
positions. Map the final neighbour relation to a rank in `onCommit`.

### Offline-first / CRDT

Treat the result as a local move operation and persist the semantic id, its
container and a rank. If remote reconciliation replaces the DOM during a drag,
the detached-node rule applies: the drag is cancelled, not resurrected.

## Custom drag feedback

`Feedback` is a dnd-kit plugin and takes options. Configure it on the manager, or
per item through `Sortable`'s `plugins`:

```ts
createSmettManager({
  plugins: (defaults) => [...defaults, Feedback.configure({ feedback: 'clone' })],
});
```

Never make the feedback element authoritative application state — it is paint.

## Auto-scroll

`AutoScroller` and `Scroller` are dnd-kit's, including scrollable-ancestor
discovery and handoff. Configure them rather than replacing them:

```ts
createSmettManager({
  plugins: (defaults) => [...defaults, AutoScroller.configure({ threshold: { x: 0, y: 0.25 } })],
});
```

Setting an axis threshold to `0` disables auto-scroll on that axis.
