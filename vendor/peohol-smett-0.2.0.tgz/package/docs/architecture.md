# Architecture

## 1. Three layers, and a rule for deciding between them

Smett sits between an application and dnd-kit. Every line of code in this
repository belongs to exactly one of three owners, and the first question about
any change is which one.

### Upstream — dnd-kit

Generic drag-and-drop infrastructure that Smett does not want to own:

- Pointer Events for mouse, touch and pen; the `PointerSensor` and its
  activation constraints, pointer capture, and the `touchmove` guard that keeps
  a live drag from being taken over by a browser pan.
- The `KeyboardSensor` and `SortableKeyboardPlugin`.
- One active drag operation, its lifecycle and its status machine.
- The draggable/droppable registry, and `Sortable` with its optimistic DOM
  reordering and index transitions.
- The collision framework, the collision observer, and the built-in detectors.
- Drag feedback: the lifted element in the top layer, the placeholder clone that
  holds its slot, and the drop animation.
- Auto-scroll, scrollable-ancestor discovery and scroll-driven shape refresh.
- Accessibility infrastructure: the live region, the screen-reader instructions,
  and the ARIA attributes on activators.
- Nested gesture ownership: a `pointerdown` is stamped by the first sensor that
  takes it, so an outer manager cannot start a second drag from the same press.
- The plugin, modifier and sensor systems, and `prefers-reduced-motion` handling
  for its own animations.

### Smett — policy

Behaviour dnd-kit deliberately leaves open, kept because an application was
measurably worse without it. Each has its own module, and each is separately
usable against a plain `DragDropManager`:

| Module | Policy |
| --- | --- |
| `hysteresis.ts` | The asymmetric reorder rule, as a collision detector plus the plugin that remembers the last swap |
| `authoritative-drop.ts` | The real `pointerup` position decides the placement |
| `safe-viewport.ts` | Viewport clamping with runtime insets, and oversized content centred |
| `activation.ts` | Huskis' activation thresholds, expressed as dnd-kit activation constraints |
| `identity.ts` | Identity is derived from the DOM, must be unique, and never invented |
| `announcements.ts` | Position-aware phrasing an application can replace, and a live region for what dnd-kit has no event for |
| `order.ts` | Pure DOM-order helpers: which items, which axis, which slot a point falls in |
| `registry.ts` | Keeps dnd-kit's entities in step with the document, and gives them the kinds a container is allowed to refuse |
| `board.ts` | Wires the above together and turns `dragend` into an application transaction |
| `manager.ts` | The preset: a `DragDropManager` with the policies installed |

### The application

Persistence, domain logic, permissions, and what a drop zone *means*. Smett never
learns what archiving is, whether a card may leave a column, or how a database
encodes positions.

**The rule.** Before implementing a general drag-and-drop mechanism in Smett,
check whether dnd-kit already has it or can express it as a sensor, plugin,
modifier or collision detector. Smett-specific code must be justifiable by a
Smett invariant. If the justification is "we wrote it before we knew dnd-kit
well", delete it.

## 2. Intent is not paint

The oldest invariant in this project, and the one that survives the migration
unchanged.

1. **Pointer intent** — where the user is trying to put the object.
2. **Painted feedback** — where the lifted object is allowed to appear.
3. **Committed order** — the durable application state after the drop.

They must not collapse into one model. A pointer can travel outside the viewport;
the feedback must stay visible and must not create page overflow; hit-testing and
auto-scroll must still follow the pointer.

In dnd-kit terms: `dragOperation.position` is the pointer and is never clamped;
modifiers clamp `dragOperation.transform`, which is what the feedback element
paints with; `dragOperation.shape` follows the painted element. Smett's collision
detector therefore reconstructs the intent rectangle itself —
`shape.initial` translated by `position.delta` — rather than reading
`shape.current`. A clamped rectangle must never decide a reorder.

## 3. Activation

`activationConstraints(policy)` maps Huskis' numbers onto dnd-kit constraints:

- mouse: `Distance(5)` — real movement, so a click stays a click;
- touch and pen: `Delay(200, tolerance 10)` — a deliberate hold that survives
  drift.

dnd-kit's own defaults are close but not the same (a mouse on a handle activates
instantly, touch waits 250 ms). Smett keeps the numbers a decade of Huskis use
tuned.

The delay is a one-shot timer inside dnd-kit, which is the only correct shape for
it: when such a timer fires, the elapsed time is already proven. Re-deriving
"has it been long enough?" from a clock at that moment loses gestures on browsers
that round `performance.now()` for privacy, and the timer is spent by then, so
nothing re-checks.

`handleSelector` and `handleRequiredFor` are enforced through the sensor's
`preventActivation` hook rather than by a custom sensor. The sensors are attached
to each `Sortable` rather than to the manager, because the activation policy
belongs to the board: two boards may deliberately share one manager so an item
can be dragged from one to the other, and they must still be able to disagree
about where a drag may start. dnd-kit binds a draggable's own sensors in
preference to the manager's, which is exactly that distinction.

Why the hook is worth having at all: an activated drag owns its gesture — dnd-kit
cancels the default on `touchmove` while dragging — so wherever a drag can start
is somewhere a finger can no longer scroll from. Narrowing that region per input
kind is a policy an application should be able to choose, and it is one hook, not
an engine.

## 4. Reorder hysteresis

`hysteresisCollision(resolveAxis)` returns a collision detector; `Hysteresis` is
the plugin that remembers what it did.

For each candidate droppable:

1. **Lane gate.** The overlap *across* the axis the list runs on must be at least
   `crossAxisRatio` (0.5) of the narrower of the two. Without it, a card in the
   next column shares this card's whole vertical band and reads as a neighbour.
2. **Overlap gate.** The overlap *along* that axis must be at least `swapRatio`
   (0.2) — or `reverseRatio` (0.5) when the candidate is the swap that just
   happened, which is additionally refused outright for `reverseLockMs` (300 ms).
3. Among admitted candidates the nearest centre wins.

The axis comes from the container's layout, measured when the DOM changes, not
from the pointer's instantaneous direction. dnd-kit's `directionBiased` reads
direction per collision pass, which a fast diagonal flick makes meaningless: a
release that jumps sideways and downwards would be judged a horizontal move.

A "reversal" is defined by identity, not direction: the droppable this policy
most recently swapped with. That needs no direction at all, and it is closer to
what Huskis actually did.

The policy is pointer-only. A keyboard drag moves in deliberate discrete steps
and dnd-kit's sortable keyboard navigation already resolves them; second-guessing
it there only fights it, so the detector defers to
`defaultCollisionDetection` for non-pointer operations.

## 5. Movement placement versus final placement

While dragging, `Sortable` and `OptimisticSortingPlugin` reorder the DOM as the
drop target changes. That is upstream's, and it is good.

At release, two things happen that are not:

1. `AuthoritativeDrop` listens for `pointerup` in the capture phase — registered
   when the manager is built, so it runs before the sensor's own listener —
   writes the real release coordinates into `dragOperation.position` and forces a
   synchronous collision recompute. dnd-kit then ends an operation that knows
   where the pointer let go. (`manager.actions.move()` defers the position update
   to a microtask, which is one turn too late when `stop()` is the very next
   listener on the same event.)
2. The board reconciles the DOM to the resolved target synchronously in its
   `dragend` handler, because dnd-kit applies the last collision result on a
   frame that never arrives when the drop happens in the same tick.

Both are needed. Neither is an optimisation to remove: a flick that crosses three
cards and lifts inside one frame is a real gesture, and coalesced pointer moves
are the normal case, not an edge case.

## 6. Safe-area clamping

`SafeViewport` is a dnd-kit modifier. It clamps the *transform*, so the pointer's
own coordinates are untouched and everything that reads them — hit-testing,
auto-scroll, the reorder policy — keeps following the user.

It differs from upstream's `RestrictToWindow` in two ways, and only two:

- insets an application supplies, re-read on every frame, so a fixed header, a
  notch or an on-screen keyboard can move at runtime;
- content larger than the space left over is centred rather than pinned to one
  edge, because pinning puts the grabbed point off screen and reintroduces the
  overflow the clamp existed to prevent.

The rendered size comes from `shape.current`, measured from the live element, so
an application's own `scale` or `rotate` is already accounted for.

## 7. Commit as a transaction

dnd-kit has no notion of persistence, and therefore none of persistence failing.
Smett's board:

1. records the board's element order at pickup;
2. lets the drop land optimistically — the gesture is over, the save is not;
3. awaits `onCommit`;
4. on rejection, restores the recorded order, re-syncs the registry, announces
   the failure and reports `onCancel('commit-error')`.

The restore skips elements that are no longer connected: a node another render
removed stays removed. Resurrecting it would put a ghost beside the new render.

`onZoneDrop` runs through the same transaction, with the item restored to its
origin *before* the callback: a zone is an action, not a destination, and if the
action fails the board must look untouched.

A pending transaction owns the board: activation is refused, for pointer and
keyboard alike, until the save settles. A rollback restores the order *its* drag
started from, so a second drag begun before the first save settles would be
undone by an older snapshot — and its own save would persist an order that is
about to be rolled back.

## 8. Identity

Semantic identity is a correctness requirement. Items, containers and configured
zones must carry a stable unique value in their data attribute or a DOM `id`.
Missing or duplicate identities throw; the engine never fabricates one, because
the id is what an application persists.

dnd-kit's feedback layer clones the lifted element to hold its slot, and the
clone carries the same attributes. The board strips the engine's identity
attributes from that clone, so an application looking its own card up mid-drag
cannot find the copy.

The clone is a **subtree**, and the whole of it is the clone. An item may itself
contain registered elements — a category is a row and a container at once — and
lifting one copies its rows too. Every DOM scan therefore skips anything inside
a placeholder, not merely the node the attribute sits on. Skipping only the root
leaves the copies visible as a second element with the same id, and then, once
the strip has been past them, as an item with no identity at all.

## 9. Cancellation and external mutation

`pointercancel` means rollback, and dnd-kit already treats it that way — as it
does `Escape`. Neither `blur`, `visibilitychange` nor `lostpointercapture`
cancels anything, upstream or here: they are not evidence that the user abandoned
the gesture.

The board keeps one safety net dnd-kit does not have: a `MutationObserver` that
stops the operation when the dragged element is removed from the document by an
external render. dnd-kit would otherwise go on dragging a node that no longer
belongs anywhere.

Cancellation reasons are distinguished — `pointercancel`, `escape`, `detached`,
`commit-error`, `destroy` — because they are different things to log and
sometimes different things to do about.

## 10. Announcements

dnd-kit's `Accessibility` plugin owns the live region, the screen-reader
instructions and the ARIA attributes. Smett supplies the words, because a board
can say *which position in which container* and the generic phrasing cannot.

Two details are Smett's:

- Movement announcements report the **projected** position — the drop target's
  index — because dnd-kit reorders the DOM a tick after it names a new target,
  and reading the item's own index would announce the position it is leaving.
- An item over itself is not announced. It would otherwise talk over the pick-up
  announcement, which is the one carrying the keyboard instructions.

A programmatic move and a failed commit both happen with no drag in progress, so
dnd-kit has no event for them. `Announcer` is a small live region of Smett's own,
created on demand, for exactly those two cases.

The words are English, and they are **replaceable**. `phrases` supplies the
builders the board calls, which is the only override that reaches all three
routes a sentence can take: dnd-kit's live region, the `onAnnounce` mirror, and
the announcer above. Handing dnd-kit its own `announcements` reaches the first
alone, so an application forbidden from shipping English strings would still
leak them from the other two. Anything left unsaid keeps Smett's phrasing, and
the builders take the parts a translation cannot recover — a zero-based index
and a total, not a formatted fragment.

## 11. Non-goals

Smett must not know what a list, a category, a folder or a universe is; how a
database encodes positions; whether dropping outside a container creates a new
one; whether a zone means delete, archive, assign or upload. Those belong in the
application. See [`extensions.md`](extensions.md).

And Smett must not grow a second copy of anything dnd-kit has. If a change starts
with "we need our own sensor / scroll loop / animation system", the answer is
almost certainly a plugin, a modifier, a collision detector, or an upstream issue.
