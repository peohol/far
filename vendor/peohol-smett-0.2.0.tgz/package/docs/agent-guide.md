# AI agent implementation guide

This document is normative for coding agents integrating or modifying Smett.

## The first rule

**Before you implement a general drag-and-drop mechanism in Smett, find out
whether it already exists in dnd-kit, or can be expressed through a dnd-kit
sensor, plugin, modifier or collision detector. Prefer the upstream primitive
over engine logic of our own.**

**Smett-specific code must be justifiable by an explicit Smett invariant or
policy.** If the only justification is "it was already here", or "we wrote it
before we understood dnd-kit", the change is a deletion.

Concretely: Smett must never contain a pointer sensor, a scroll loop, a
coordinate system, an animation system, a placeholder implementation, a live
region for drag events, or a pointer-ownership registry. All of those exist
upstream and are in use. If you believe one of them is inadequate, the fix is a
minimal extension of dnd-kit's own mechanism — a plugin, a modifier, a detector —
plus a note in [`roadmap.md`](roadmap.md) about what to raise upstream.

## Where a requirement goes

| Requirement | Owner |
| --- | --- |
| Reading raw input | dnd-kit sensor |
| When a press becomes a drag | dnd-kit activation constraints (Smett supplies the numbers) |
| Which droppable a drag is over | dnd-kit collision framework (Smett supplies the policy detector) |
| Where the lifted element is painted | dnd-kit `Feedback` plus modifiers (Smett supplies `SafeViewport`) |
| Reordering the DOM during the drag | dnd-kit `Sortable` |
| Where a *release* lands | Smett (`AuthoritativeDrop` and the board's reconcile) |
| Whether a reorder is stable enough to make | Smett (`Hysteresis`) |
| Whether an identity may be persisted against | Smett (`identity.ts`) |
| What a completed drop means | the application's `onCommit` / `onZoneDrop` |
| Whether a drop may be undone | Smett's transaction, driven by the application throwing |
| What archiving, deleting or assigning means | the application |

If a change mixes three or more of these in one function, the design is
regressing toward the monolithic controller this architecture exists to avoid.

## Integration sequence

### 1. Stable semantic ids

Every draggable item needs a stable `data-dnd-id` (or a custom `idAttribute`).
Every container needs `data-dnd-container`. Do not use visual indices as
identity. Missing or duplicate ids are configuration errors and fail fast; never
add a generated or random fallback.

### 2. Real containers

The DOM must contain actual container elements matching `containerSelector`. Do
not infer authoritative membership from CSS columns or masonry paint order.

Where two kinds of item share a container and one of them owns a container of
its own, name the kinds with `itemType` and say what each container takes with
`containerAccept`. A nesting rule is a rule about kinds, and dnd-kit's `accept`
gate already decides them — during the drag, so a container that will not take
the item never becomes a target. Do not express it as a branch in a policy
module, and do not undo the drop afterwards.

### 3. Decide the handle question deliberately

A handle prevents conflict with links, inputs, text selection and scrolling. On
touch and pen, decide it by asking what the user gives up: an activated drag owns
the gesture, so **wherever a drag can start is somewhere the finger can no longer
scroll from**. If items fill a scrollable surface, require a handle there and
leave the rest of the item scrollable:

```ts
handleSelector: '.drag-handle',
handleRequiredFor: ['touch', 'pen'],
```

Give the handle `touch-action: none`, and size it for the input that depends on
it: once touch can only lift from the handle, a glyph-sized target is not enough.

### 4. Keep persistence outside the board

Implement `onCommit(result)` and mutate authoritative state there. Throw or
reject to roll the board back — never swallow a failed write and leave the
visual order pretending it succeeded.

For framework integrations, do not let a re-render remove the dragged element
during a gesture. If it does, Smett correctly cancels the drag as detached.

### 5. Provide a non-drag path

Keyboard dragging is on by default. Semantic zones are pointer-only by design, so
a zone action needs an ordinary control too. `board.moveBy(item, ±1)` and
`board.moveTo(item, containerId, index)` exist for single-action alternatives;
the Release Board uses both. They go through the same acceptance gate as a drag,
so ask `board.accepts(item, containerId)` before offering a control rather than
letting the user press one that does nothing.

### 6. Test in real browsers

Pure unit tests are not enough for drag-and-drop. Test real geometry, real
pointer events, real scrolling and real cancellation. At minimum, cover the
scenarios listed at the end of [`huskis-extraction.md`](huskis-extraction.md).

## Invariants agents must not break

### A — the release is authoritative

`pointerup` must apply the actual release coordinates before the operation ends,
and the DOM must be reconciled to the resolved target synchronously. Never rely
only on the last delivered `pointermove`: dnd-kit coalesces moves onto an
animation frame, so a fast gesture's last frame may never run.

The preview owes the same answer where nothing else can give it. dnd-kit sorts
optimistically against *items*, so an **empty container** moves nothing: there
is no row in it to be over, so it can only ever be a container target, and the
placeholder is left showing a destination the release will not honour. The board
therefore runs the same `insertByPoint` on `dragmove`/`dragover` that the drop
will run, against the same target and from the same point. Keep those two as one
decision made twice; do not give the preview a rule of its own.

That is also the whole of its scope. A container that still holds rows is
dnd-kit's to sort on every frame, including the frames a tall neighbour leaves
the container itself as the target — never preview into one. Two rules on one
list is worse than one: `insertByPoint` reads the siblings' centres in a layout
the placeholder is not part of yet, so the move it makes shifts every centre it
just read, and dnd-kit's overlap rule then carries the row on past what the
point asked for. The release is authoritative there, and it is measured once,
when nothing is left to shift under it.

### B — intent is unclamped

Never use the clamped feedback rectangle for a reorder decision or for
auto-scroll. A user can intend a position the paint is not allowed to reach.
Smett's collision detector reconstructs the intent rectangle for this reason;
do not "simplify" it to `dragOperation.shape.current`.

### C — no broad "gesture lost" heuristics

Do not cancel on `blur`, `visibilitychange` or `lostpointercapture`. Cancel on an
actual `pointercancel`, an explicit user cancel, board destruction, or a dragged
element that was removed from the document.

### D — cancellation is rollback

A cancelled drag does not persist a new order, and neither does a failed commit.

### E — a detached item stays detached

If another render removes the dragged element, clean up. Do not reinsert the old
node; that creates a ghost beside the new render.

### F — hysteresis is asymmetric

Forward movement stays eager. Only undoing the swap that just happened receives
the stronger threshold and the time lock. Do not replace this with one globally
high threshold: that buys the same stability by making every reorder sluggish.

### G — the lane gate is part of the policy

A neighbour must occupy the same row or column before its position along the
axis of travel means anything. Removing the cross-axis gate makes every card in
the next column a swap candidate.

### H — the reorder axis comes from the layout

Take the axis from the container, not from the pointer's instantaneous
direction. A fast diagonal flick makes an instantaneous direction meaningless.

### I — an activated drag owns its gesture

dnd-kit cancels the default on `touchmove` while dragging. Do not weaken this
into a CSS-only rule: `touch-action` is latched when the pointer lands, before
the engine knows a drag is coming. Pay the cost deliberately with
`handleRequiredFor` rather than by letting the browser cancel drags.

### J — semantic actions are the application's

Trash, delete, archive, create-container and assign-user are not reorder
mechanics. Model them as zones or consumer callbacks. Never add an entity-type
branch to a policy module.

### K — one identity, one element

Identity comes from the DOM, must be unique, and is never invented. The clone
dnd-kit leaves behind must not claim it — and "the clone" is the whole subtree,
not the node the attribute sits on. An item that contains registered elements is
copied with them, so a scan that skips only the clone's root sees the copies.

## Working on the policies

- Keep the decision in a pure exported function (`admitsSwap`, `clampAxis`,
  `overlapRatio`, `crossAxisOverlap`, `insertByPoint`) and the wiring in the
  plugin, modifier or board around it. That is what makes the unit suite
  meaningful.
- Add a unit test for every algorithmic edge case, and a browser test for every
  change to pointer, DOM or scroll behaviour.
- Keep TypeScript `strict` clean.
- Run `npm test` before committing, and the browser suites before believing a
  behavioural change.

## Review checklist

Before proposing a change, answer all of these:

- Could dnd-kit do this instead? What did you check?
- Which Smett invariant does this code serve? Name it.
- Does a click still stay a click, and can touch still scroll where it should?
- Does a fast release still land where the pointer let go?
- Can a nearly still pointer flicker between two slots?
- Is a card in the next column still not a neighbour of this one?
- Does the reorder axis still come from the layout?
- Can the painted feedback create page overflow, or hide under a safe inset?
- Does `pointercancel` restore the origin, and do `blur`/`visibilitychange` still
  do nothing?
- What happens if a framework removes the item during a drag?
- What happens if persistence rejects?
- Is there an equivalent keyboard and single-action path for every drag action,
  and does it refuse what the drag refuses? A path that reaches a place the
  gesture cannot is a hole in the rule, not an alternative to it.
- Do the announcements still say the position the item is going to?
- Is every sentence the board says still a `Phrases` builder? A literal is a
  sentence an application cannot translate, and nothing else would fail.
- Are all semantic ids stable and unique, and does the placeholder still have none?
- Did the amount of Smett-specific drag-and-drop code go down, or at least not up?

If any answer is unknown, add a test before changing the algorithm.
