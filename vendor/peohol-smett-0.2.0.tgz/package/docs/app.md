# Release Board — the showcase application

`app/` contains a small planning board built on nothing but the published API of
Smett. It exists for three reasons:

1. a second real consumer keeps the public API honest;
2. the invariants in [`architecture.md`](architecture.md) are easier to believe
   when you can trigger them;
3. a deployed URL can be **UI tested in a real browser**, not just described.

The board is deliberately app-shaped rather than demo-shaped: durable state, an
asynchronous save that can fail, an archive with restore, and a way to add cards.
dnd-kit owns the gesture, Smett owns the policy, the app owns the data.

## What each control demonstrates

| In the app | Behaviour | Owner |
| --- | --- | --- |
| Drag a card between columns | Activation, collision, sorting, feedback | dnd-kit |
| Drag within a column | The asymmetric reorder policy, and the lane gate that keeps the next column out of it | Smett |
| Flick a card and release immediately | The release position decides the placement | Smett |
| Drag a card straight up or down on touch | A live drag owns the gesture; the browser's pan cannot end it | dnd-kit |
| **Drag from** | `handleSelector` and `handleRequiredFor`: the handle requirement scoped per input kind | Smett |
| Swipe from a card on touch | Nothing between a card and the page can swallow the swipe | app CSS |
| Press and hold a card body on touch | The flip side: only the grip lifts, so the card stays a scroll surface | Smett |
| **Fail next save** | `onCommit` is a transaction; a rejected save rolls the card back to its original index in its original column | Smett |
| **Safe insets** | Unclamped pointer intent versus feedback clamped to the safe viewport | Smett |
| **Save latency** | `onCommit` may be asynchronous; the gesture is finished before persistence starts | Smett |
| Archive zone | Zones are semantic actions: the engine reports a zone id, the app decides what archiving means | Smett + app |
| Dwell over the archive while dragging | `onDropTarget` reports what the drag is over; the 400 ms peek is the app's own four lines | app |
| ↑ ↓ buttons | `moveBy()`, a WCAG 2.2 dragging-movement alternative | Smett |
| → button | `moveTo()`, the cross-container counterpart | Smett |
| ✕ button | The keyboard-reachable equivalent of the archive zone | app |
| <kbd>Space</kbd> / arrows / <kbd>Esc</kbd> | Keyboard pick up, move, drop and cancel | dnd-kit |
| Screen reader panel | `onAnnounce` — the same text the live region carries | Smett |
| **Inject a duplicate ID** | Strict identity: duplicates are reported through `onError` rather than guessed | Smett |
| Reload the page | The commit callback is the only persistence boundary | app |

Auto-scroll is exercised when a column is taller than its height cap; that
behaviour has dedicated coverage in the library suite (`e2e/`), so the app suite
does not duplicate it.

## Architecture of the app

```
app/index.html    static markup: containers carry data-dnd-container,
                  cards carry data-dnd-id, the archive carries data-dnd-zone
app/app.js        state, a fake server, and one SortableBoard
app/styles.css    presentation, including the engine's hooks
                  ([data-dnd-dragging], [data-dnd-placeholder], [data-dnd-over])
```

Three rules keep the app honest:

- **The snapshot is derived from the DOM the engine just produced**, before the
  save is awaited. If the save rejects, the app's state was never mutated and the
  engine's rollback is the only correction needed.
- **The app never re-renders the board during a gesture.** Re-rendering would
  fight the engine for ownership of the DOM. Full renders happen on load, on
  reset and on archive restore only.
- **Every persisted change runs through one queue.** Drops, archive actions,
  restores and additions all serialise, so two overlapping changes cannot
  snapshot the same DOM and have the later write drop the earlier change.

## Build and deployment

`vercel.json` pins the whole contract:

```json
{
  "installCommand": "npm install --ignore-scripts",
  "buildCommand": "npm run build:app",
  "outputDirectory": "public"
}
```

`npm run build:app` compiles the library with `tsc`, bundles the browser artefact
with esbuild, and copies `app/` plus `dist/smett.browser.js` into `public/`,
where the app imports the engine as `./smett.js`.

The bundle is why the deployed artefact is no longer raw ESM: Smett has a runtime
dependency now, and bare specifiers such as `@dnd-kit/dom` do not resolve in a
browser without an import map or a bundler. One self-contained module is the
simpler of the two.

`--ignore-scripts` keeps Vercel from downloading Playwright browsers during the
install step. `public/` is generated and is not committed.

## Running the UI suite

The suite in `e2e-app/` only touches the rendered UI, so the same specs run
against a local build and against a deployment:

```bash
npm run test:app        # builds public/, serves it, runs Chromium
npm run test:app:all    # same, in Chromium, Firefox and WebKit

APP_URL=https://your-deployment.vercel.app npm run test:deployed
```

One detail worth knowing when writing app tests: while a card is lifted, dnd-kit
leaves a clone of it in the layout. Smett strips the engine's identity attributes
from that clone, but an app's own `data-testid` is still there twice — so a card
locator needs `:not([data-dnd-placeholder])`.

### Protected deployments

This project has Vercel Authentication enabled for every `*.vercel.app` URL, so
an unauthenticated request to a preview gets the SSO wall instead of the app.
Create a **Protection Bypass for Automation** secret in the Vercel project and
export it:

```bash
export VERCEL_AUTOMATION_BYPASS_SECRET=…
APP_URL=https://your-deployment.vercel.app npm run test:deployed
```

`playwright.app.config.js` sends it as `x-vercel-protection-bypass` together with
`x-vercel-set-bypass-cookie`, which is enough for the page and its module imports
to load.

The `Deployed UI tests` workflow does the same automatically on every successful
Vercel deployment, provided the same value is stored as a repository secret named
`VERCEL_AUTOMATION_BYPASS_SECRET`. Without the secret the workflow reports that
it was skipped rather than failing.
